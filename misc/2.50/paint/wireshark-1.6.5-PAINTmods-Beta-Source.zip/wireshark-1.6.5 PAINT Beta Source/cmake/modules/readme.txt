The following modules have been copied from CMake trunk _without_ modifications:

* FindZLIB.cmake
